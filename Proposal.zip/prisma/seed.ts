import "dotenv/config";
import bcrypt from "bcryptjs";
import { PrismaPg } from "@prisma/adapter-pg";
import { PrismaClient } from "../src/generated/prisma/client";
import { DEFAULT_PAYMENT_TERMS, DEFAULT_PICS, DEFAULT_TERMS } from "../src/lib/proposal-defaults";

const prisma = new PrismaClient({
  adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL }),
});

async function main() {
  // Venues (content taken from the Event Proposal PDF).
  await prisma.venue.upsert({
    where: { key: "elysium" },
    update: {},
    create: {
      key: "elysium",
      name: "Elysium",
      tagline: "Glass, bamboo and uninterrupted ocean",
      description:
        "In this glass and bamboo cocooned lounge, uninterrupted ocean views and majestic sunsets set the scene. Tailored for tranquillity and fully air-conditioned, Elysium is an idyllic backdrop for weddings, corporate gatherings and special events, and it doubles as a chapel.",
      seated: 50,
      standing: 100,
      features: [
        "Dedicated events space",
        "Uninterrupted ocean views",
        "Clifftop location",
        "Majestic sunsets",
        "Fully air-conditioned",
        "Multiple room setup options",
        "Buggy drop off access",
        "Dedicated entrance",
      ],
      suitableFor: [
        "Small to medium events",
        "Weddings",
        "Private sit down dinners",
        "Corporate talks",
        "Pre and post wedding events",
        "Sunset cocktails and wine bar",
      ],
      imageUrl: "/brand/venue-elysium.jpg",
      sortOrder: 1,
    },
  });

  // Editable defaults for new proposals.
  await prisma.setting.upsert({
    where: { key: "defaults" },
    update: {},
    create: {
      key: "defaults",
      value: { pics: DEFAULT_PICS, paymentTerms: DEFAULT_PAYMENT_TERMS, terms: DEFAULT_TERMS },
    },
  });

  // First admin user. Credentials come from the environment, never from source.
  const email = process.env.ADMIN_EMAIL?.trim().toLowerCase();
  const password = process.env.ADMIN_PASSWORD;
  const name = process.env.ADMIN_NAME?.trim() || "Admin";
  if (!email || !password) {
    console.warn("ADMIN_EMAIL / ADMIN_PASSWORD not set: skipping admin user.");
    return;
  }
  if (password.length < 12) throw new Error("ADMIN_PASSWORD must be at least 12 characters");
  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) {
    console.log(`Admin ${email} already exists; password left unchanged.`);
    return;
  }
  await prisma.user.create({
    data: { email, name, role: "ADMIN", passwordHash: await bcrypt.hash(password, 12) },
  });
  console.log(`Created admin user ${email}.`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exitCode = 1;
  })
  .finally(() => prisma.$disconnect());
