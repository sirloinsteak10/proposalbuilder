import { proposalDataSchema, type ProposalData } from "@/lib/schemas/proposal";

export const DEFAULT_PAYMENT_TERMS = [
  "1st deposit 50% required upon signing of proposal: {DEPOSIT}",
  "Balance payment due on {BALANCE_DATE}: {BALANCE}",
  "Proof of transfer is to be emailed to: sisylia@lunabeachclubbali.com, tina@lunabeachclubbali.com, events@lunabeachclubbali.com and suma@lunabeachclubbali.com",
  "Deposit payment is non-refundable.",
].join("\n");

export const DEFAULT_TERMS: string[] = [
  "Cancellation: upon signed confirmation, a 50% penalty charge from the total expenses will be applied.",
  "Cancellation: if the event is cancelled less than 14 days prior to the event, a 100% penalty charge from the total expenses will be applied.",
  "Amendments: the final number of guests, including any additional attendees, must be confirmed at least 7 days prior to the event.",
  "Credit policy: Food & Beverage credit including Bar Tab credit is valid for on-site consumption during the event. Takeaway of bottles is not permitted. Corkage fee applies to bottles (wines, spirits, champagnes) brought from outside the venue.",
  "Tax & service: government tax of 16% is applicable, along with a 5% contribution to Luna Beach Club's CSR (Corporate Social Responsibility) called Nuanu Social Fund, benefiting impoverished local communities through charity projects, along with a 2.2% service charge, for a total of 23.2% tax & service.",
  "Dietary restrictions: the venue requires the information regarding guests' dietary restrictions, if any, one week prior to the event.",
  'Force majeure: in the case of a "Force Majeure", such as disasters, government regulations, strikes, civil disorder, weather conditions, or other emergencies which would make it illegal or impossible to provide the event facilities or to hold the event, it is not the responsibility of the host venue, Luna Beach Club, to activate the event.',
];

export const DEFAULT_PICS = {
  picName: "Tina Ardie",
  picTitle: "Events Manager",
  picEmail: "tina@lunabeachclubbali.com",
  picPhone: "+628113851138",
  pic2Name: "Sisylia Paramitha",
  pic2Title: "Sales Executive",
  pic2Email: "sisylia@lunabeachclubbali.com",
  pic2Phone: "+628785399069",
} as const;

export function todayIso(now = new Date()): string {
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, "0");
  const d = String(now.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

/** A blank proposal pre-filled with the standard PICs, payment terms and T&C. */
export function newProposalData(overrides: Partial<ProposalData> = {}): ProposalData {
  return proposalDataSchema.parse({
    issueDate: todayIso(),
    ...DEFAULT_PICS,
    venueKey: "elysium",
    paymentTerms: DEFAULT_PAYMENT_TERMS,
    terms: DEFAULT_TERMS,
    ...overrides,
  });
}
