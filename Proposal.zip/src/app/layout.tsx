import type { Metadata } from "next";
import { Poppins } from "next/font/google";
import { Providers } from "@/components/providers";
import "./globals.css";

const poppins = Poppins({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
  variable: "--font-poppins",
  display: "swap",
});

const SITE_URL = process.env.SITE_URL || "https://proposal.lunabeachclubbali.com";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: "Luna Proposal Builder",
  description: "Create and export event proposals for Luna Beach Club.",
  applicationName: "Luna Proposal Builder",
  robots: { index: false, follow: false },
  openGraph: {
    type: "website",
    siteName: "Luna Beach Club Bali",
    title: "Luna Proposal Builder",
    description: "Create and export event proposals for Luna Beach Club.",
  },
  twitter: { card: "summary_large_image", title: "Luna Proposal Builder" },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={poppins.variable}>
      <body>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
